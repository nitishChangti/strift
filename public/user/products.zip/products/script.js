$(function () {
    $(".navSection").load("../home/header.html");
    $("footer").load("../home/footer.html");
});

document.addEventListener('DOMContentLoaded', () => {
    const storedProductData = localStorage.getItem('productData');

    if (storedProductData) {
        // console.log('Retrieved product data:', storedProductData);
        try {
            displayProducts(JSON.parse(storedProductData));
        } catch (error) {
            console.error("Error parsing product data:", error);
        }
    } else {
        console.log('No product data found in localStorage.');
    }
});

function displayProducts(products) {
    const productsContainer = document.querySelector('.product-grid .grid');
    if (!productsContainer) {
        console.error("Product container not found.");
        return;
    }
    console.log('Displaying products:', products[0].variants.color[0].price);
    productsContainer.innerHTML = ''; // Clear previous products
    products.forEach(product => {
        const productElement = document.createElement('div');
        productElement.className = 'product-item';
        productElement.innerHTML = `
            <img src="${product.image}" alt="${product.name}" style="width: 100%; height: 280px; object-fit: cover;">
            <h3>${product.name}</h3>
            <p>${product.variants.color[0].price}</p>
        `;
        productsContainer.appendChild(productElement);
        productElement.style.border = '1px solid #ccc';
        productElement.style.width = 'auto';
        productElement.style.display = 'inline-block';
        productElement.setAttribute('data-product-id', product._id);
    });
    productsContainer.addEventListener('click', async (event) => {
        const productElement = event.target.closest('.product-item');
        if (productElement) {
            const productId = productElement.getAttribute('data-product-id');
            console.log('Product clicked:', productId);
            window.location.pathname = `/productdetails/${productId}`;
            // You can add more actions here, such as redirecting to a product detail page
            // try {
            //     const response = await fetch(`/ api / products / ${ productId } `,
            //         {
            //             method: 'GET',
            //             headers: {
            //                 'Content-Type': 'application/json',
            //             },
            //         });
            //     if (response.ok) {
            //         const productData = await response.json();
            //         console.log('Product data:', productData);
            //     }
            //     else {
            //         const errData = await response.json();
            //         console.error('Failed to fetch product data.', errData);
            //     }
            // } catch (error) {
            //     console.error("Error parsing product data:", error);
            // }
        }
    });
}

// Function to store product data in localStorage
function storeProductData(data) {
    localStorage.setItem('productData', JSON.stringify(data));
}

// Example usage:
// storeProductData([{name: "Product 1", image: "image1.jpg", price: "$10"}]);
